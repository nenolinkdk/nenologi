# Poetry examples
